import Foundation
import SwiftUI

final class AppStore: ObservableObject {
    @Published var tasks: [DailyTask] = [
        DailyTask(title: "Medicin", subtitle: "Morgon", icon: "pills.fill"),
        DailyTask(title: "Borsta tänderna", subtitle: "Morgon", icon: "mouth.fill"),
        DailyTask(title: "Dagens viktigaste uppgift", subtitle: "Välj en sak", icon: "target"),
        DailyTask(title: "Städa", subtitle: "5 minuter räcker", icon: "sparkles"),
        DailyTask(title: "Räkningskoll", subtitle: "Är allt betalt?", icon: "creditcard.fill")
    ]

    @Published var purchases: [Purchase] = []
    @Published var brainDump: [BrainDumpItem] = []
    @Published var savingsGoal: Double = 10_000
    @Published var savedAmount: Double = 0
    @Published var quitSmokingDate: Date = Calendar.current.date(from: DateComponents(year: 2026, month: 9, day: 10)) ?? .now
    @Published var cigarettesPerDay: Int = 10
    @Published var cigarettePackPrice: Double = 80
    @Published var cigarettesPerPack: Int = 20

    private let key = "adhd-vardag-store-v1"

    init() {
        load()
    }

    func toggleTask(_ task: DailyTask) {
        guard let index = tasks.firstIndex(where: { $0.id == task.id }) else { return }
        tasks[index].isDone.toggle()
        save()
    }

    func addPurchase(title: String, amount: Double, category: String) {
        purchases.insert(Purchase(title: title, amount: amount, category: category), at: 0)
        save()
    }

    func addBrainDump(_ text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        brainDump.insert(BrainDumpItem(text: trimmed), at: 0)
        save()
    }

    var todaysSpending: Double {
        purchases.filter { Calendar.current.isDateInToday($0.date) }.reduce(0) { $0 + $1.amount }
    }

    var daysUntilQuit: Int {
        max(0, Calendar.current.dateComponents([.day], from: Calendar.current.startOfDay(for: .now), to: Calendar.current.startOfDay(for: quitSmokingDate)).day ?? 0)
    }

    var smokeFreeDays: Int {
        max(0, Calendar.current.dateComponents([.day], from: Calendar.current.startOfDay(for: quitSmokingDate), to: Calendar.current.startOfDay(for: .now)).day ?? 0)
    }

    var cigarettesAvoided: Int {
        smokeFreeDays * cigarettesPerDay
    }

    var smokingMoneySaved: Double {
        guard cigarettesPerPack > 0 else { return 0 }
        return Double(cigarettesAvoided) / Double(cigarettesPerPack) * cigarettePackPrice
    }

    func save() {
        let snapshot = Snapshot(tasks: tasks, purchases: purchases, brainDump: brainDump, savingsGoal: savingsGoal, savedAmount: savedAmount, quitSmokingDate: quitSmokingDate, cigarettesPerDay: cigarettesPerDay, cigarettePackPrice: cigarettePackPrice, cigarettesPerPack: cigarettesPerPack)
        if let data = try? JSONEncoder().encode(snapshot) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    func load() {
        guard let data = UserDefaults.standard.data(forKey: key),
              let snapshot = try? JSONDecoder().decode(Snapshot.self, from: data) else { return }
        tasks = snapshot.tasks
        purchases = snapshot.purchases
        brainDump = snapshot.brainDump
        savingsGoal = snapshot.savingsGoal
        savedAmount = snapshot.savedAmount
        quitSmokingDate = snapshot.quitSmokingDate
        cigarettesPerDay = snapshot.cigarettesPerDay
        cigarettePackPrice = snapshot.cigarettePackPrice
        cigarettesPerPack = snapshot.cigarettesPerPack
    }
}

private struct Snapshot: Codable {
    var tasks: [DailyTask]
    var purchases: [Purchase]
    var brainDump: [BrainDumpItem]
    var savingsGoal: Double
    var savedAmount: Double
    var quitSmokingDate: Date
    var cigarettesPerDay: Int
    var cigarettePackPrice: Double
    var cigarettesPerPack: Int
}
