import SwiftUI

struct RoutinesView: View {
    @State private var morning = [
        "Medicin", "Borsta tänderna", "Drick vatten", "Ät något", "Kolla dagens kalender", "Ta med nycklar, plånbok och telefon"
    ]
    @State private var done = Set<String>()

    var body: some View {
        NavigationStack {
            List(morning, id: \.self) { item in
                Button {
                    if done.contains(item) { done.remove(item) } else { done.insert(item) }
                } label: {
                    HStack {
                        Image(systemName: done.contains(item) ? "checkmark.circle.fill" : "circle")
                            .foregroundStyle(done.contains(item) ? .green : .secondary)
                        Text(item).foregroundStyle(.primary)
                    }
                }
            }
            .navigationTitle("Rutiner")
            .toolbar { Text("Morgon").font(.subheadline).foregroundStyle(.secondary) }
        }
    }
}
