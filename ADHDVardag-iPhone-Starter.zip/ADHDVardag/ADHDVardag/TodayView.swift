import SwiftUI

struct TodayView: View {
    @EnvironmentObject var store: AppStore
    @State private var brainText = ""
    @State private var showStuck = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 14) {
                    nextEventCard

                    VStack(alignment: .leading, spacing: 10) {
                        Text("Dagens uppgifter").font(.headline)
                        ForEach(store.tasks) { task in
                            Button { store.toggleTask(task) } label: {
                                HStack(spacing: 12) {
                                    Image(systemName: task.icon)
                                        .frame(width: 34, height: 34)
                                        .background(Color.indigo.opacity(0.12))
                                        .clipShape(RoundedRectangle(cornerRadius: 10))
                                    VStack(alignment: .leading) {
                                        Text(task.title).fontWeight(.semibold)
                                        Text(task.subtitle).font(.caption).foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    Image(systemName: task.isDone ? "checkmark.circle.fill" : "circle")
                                        .foregroundStyle(task.isDone ? .green : .secondary)
                                }
                                .padding()
                                .background(.background)
                                .clipShape(RoundedRectangle(cornerRadius: 16))
                                .shadow(color: .black.opacity(0.04), radius: 8, y: 2)
                            }
                            .buttonStyle(.plain)
                        }
                    }

                    HStack(spacing: 12) {
                        Button { } label: {
                            Label("Skriv ner något", systemImage: "plus")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(.indigo.opacity(0.8))

                        Button { showStuck = true } label: {
                            Label("Jag har fastnat", systemImage: "lifepreserver")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.bordered)
                    }

                    tipCard
                    goalSummary
                }
                .padding()
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Idag")
            .sheet(isPresented: $showStuck) { StuckView() }
        }
    }

    private var nextEventCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Nästa händelse").font(.caption).foregroundStyle(.indigo)
            HStack {
                VStack(alignment: .leading) {
                    Text("Kalendern är redo").fontWeight(.semibold)
                    Text("Lägg in nästa viktiga tid").font(.subheadline)
                }
                Spacer()
                Image(systemName: "calendar.badge.plus").font(.title2)
            }
        }
        .padding()
        .background(Color.indigo.opacity(0.12))
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    private var tipCard: some View {
        HStack(spacing: 12) {
            Image(systemName: "lightbulb.fill")
            VStack(alignment: .leading) {
                Text("Dagens lilla tips").fontWeight(.semibold)
                Text("Gör bara två minuter. Det räcker för att komma igång.")
                    .font(.subheadline)
            }
            Spacer()
        }
        .padding()
        .background(Color.green.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    private var goalSummary: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Mina mål").font(.headline)
            HStack {
                VStack(alignment: .leading) {
                    Text("🚭 Rökfri").fontWeight(.semibold)
                    Text(store.daysUntilQuit > 0 ? "\(store.daysUntilQuit) dagar kvar" : "\(store.smokeFreeDays) rökfria dagar")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                VStack(alignment: .trailing) {
                    Text("💰 Sparat").fontWeight(.semibold)
                    Text("\(Int(store.savedAmount + store.smokingMoneySaved)) kr")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
        }
        .padding()
        .background(Color.orange.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }
}
