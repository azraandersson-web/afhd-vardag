import SwiftUI

struct MoreView: View {
    var body: some View {
        NavigationStack {
            List {
                NavigationLink { GoalsView() } label: { Label("Mina mål", systemImage: "medal.fill") }
                NavigationLink { BrainDumpView() } label: { Label("Brain dump", systemImage: "brain.head.profile") }
                NavigationLink { CleaningView() } label: { Label("Städschema", systemImage: "house.fill") }
                NavigationLink { BillCheckView() } label: { Label("Räkningskoll", systemImage: "checkmark.seal.fill") }
                NavigationLink { StuckView() } label: { Label("Jag har fastnat", systemImage: "lifepreserver") }
            }
            .navigationTitle("Mer")
        }
    }
}

struct GoalsView: View {
    @EnvironmentObject var store: AppStore

    var body: some View {
        List {
            Section("🚭 Rökfri") {
                DatePicker("Stoppdatum", selection: $store.quitSmokingDate, displayedComponents: .date)
                Stepper("Cigaretter per dag: \(store.cigarettesPerDay)", value: $store.cigarettesPerDay, in: 1...60)
                HStack { Text("Dagar kvar"); Spacer(); Text("\(store.daysUntilQuit)") }
                HStack { Text("Rökfria dagar"); Spacer(); Text("\(store.smokeFreeDays)") }
                HStack { Text("Cigaretter inte rökta"); Spacer(); Text("\(store.cigarettesAvoided)") }
                HStack { Text("Pengar sparade"); Spacer(); Text(store.smokingMoneySaved, format: .currency(code: "SEK")) }
            }

            Section("💰 Sparmål") {
                HStack {
                    Text("Mål")
                    Spacer()
                    TextField("10000", value: $store.savingsGoal, format: .number)
                        .keyboardType(.decimalPad)
                        .multilineTextAlignment(.trailing)
                }
                HStack {
                    Text("Eget sparande")
                    Spacer()
                    TextField("0", value: $store.savedAmount, format: .number)
                        .keyboardType(.decimalPad)
                        .multilineTextAlignment(.trailing)
                }
                ProgressView(value: min((store.savedAmount + store.smokingMoneySaved) / max(store.savingsGoal, 1), 1))
            }
        }
        .navigationTitle("Mina mål")
        .onDisappear { store.save() }
    }
}

struct BrainDumpView: View {
    @EnvironmentObject var store: AppStore
    @State private var text = ""

    var body: some View {
        VStack(spacing: 12) {
            HStack {
                TextField("Skriv ner något…", text: $text, axis: .vertical)
                    .textFieldStyle(.roundedBorder)
                Button("Spara") { store.addBrainDump(text); text = "" }
                    .buttonStyle(.borderedProminent)
            }
            .padding()

            List(store.brainDump) { item in
                Text(item.text)
            }
        }
        .navigationTitle("Brain dump")
    }
}

struct CleaningView: View {
    let days = [
        ("Måndag", "Torka av köksbänken + töm soporna"),
        ("Tisdag", "Dammsug hallen + plocka 5 minuter"),
        ("Onsdag", "Rengör handfatet + byt handdukar"),
        ("Torsdag", "Plocka vardagsrum + diskmaskin"),
        ("Fredag", "Dammsug ett rum + kylskåpskoll"),
        ("Lördag", "Valfri liten uppgift"),
        ("Söndag", "Valfri liten uppgift")
    ]
    var body: some View {
        List(days, id: \.0) { day, task in
            VStack(alignment: .leading) { Text(day).fontWeight(.semibold); Text(task).font(.subheadline).foregroundStyle(.secondary) }
        }
        .navigationTitle("Städschema")
    }
}

struct BillCheckView: View {
    @State private var bills = ["Hyra", "El", "Mobil", "Internet", "Försäkring", "Övriga räkningar"]
    @State private var paid = Set<String>()

    var body: some View {
        List(bills, id: \.self) { bill in
            Button {
                if paid.contains(bill) { paid.remove(bill) } else { paid.insert(bill) }
            } label: {
                HStack {
                    Image(systemName: paid.contains(bill) ? "checkmark.circle.fill" : "circle")
                        .foregroundStyle(paid.contains(bill) ? .green : .secondary)
                    Text(bill).foregroundStyle(.primary)
                }
            }
        }
        .navigationTitle("Räkningskoll")
    }
}

struct StuckView: View {
    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 20) {
                Text("Du behöver bara göra nästa lilla steg.").font(.title2).bold()
                Label("Res dig upp.", systemImage: "figure.stand")
                Label("Ta några klunkar vatten.", systemImage: "drop.fill")
                Label("Välj något som tar under 5 minuter.", systemImage: "checklist")
                Label("Sätt en timer på 5 minuter.", systemImage: "timer")
                Label("När tiden är slut får du välja igen.", systemImage: "heart.fill")
                Spacer()
                HStack {
                    Button("2 minuter") { }
                    Button("5 minuter") { }
                    Button("10 minuter") { }
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
            .navigationTitle("Jag har fastnat")
        }
    }
}
