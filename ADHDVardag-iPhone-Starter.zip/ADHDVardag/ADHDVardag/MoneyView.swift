import SwiftUI

struct MoneyView: View {
    @EnvironmentObject var store: AppStore
    @State private var showAddPurchase = false

    var body: some View {
        NavigationStack {
            List {
                Section("Idag") {
                    HStack {
                        Label("Dagens köp", systemImage: "bag.fill")
                        Spacer()
                        Text(store.todaysSpending, format: .currency(code: "SEK"))
                            .fontWeight(.bold)
                    }
                    Button("+ Lägg till köp") { showAddPurchase = true }
                }

                Section("Sparmål") {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack { Text("Sparat"); Spacer(); Text("\(Int(store.savedAmount)) / \(Int(store.savingsGoal)) kr") }
                        ProgressView(value: min(store.savedAmount / max(store.savingsGoal, 1), 1))
                    }
                }

                Section("Rökfri = pengar kvar") {
                    HStack {
                        Text("Uppskattat sparat")
                        Spacer()
                        Text(store.smokingMoneySaved, format: .currency(code: "SEK"))
                            .fontWeight(.semibold)
                    }
                }

                Section("Senaste köp") {
                    if store.purchases.isEmpty {
                        Text("Inga köp registrerade ännu").foregroundStyle(.secondary)
                    } else {
                        ForEach(store.purchases.prefix(8)) { purchase in
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(purchase.title)
                                    Text(purchase.category).font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                Text(purchase.amount, format: .currency(code: "SEK"))
                            }
                        }
                    }
                }
            }
            .navigationTitle("Pengar")
            .sheet(isPresented: $showAddPurchase) { AddPurchaseView() }
        }
    }
}

struct AddPurchaseView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var store: AppStore
    @State private var title = ""
    @State private var amount = ""
    @State private var category = "Övrigt"

    let categories = ["Mat & dryck", "Transport", "Shopping", "Räkningar", "Övrigt"]

    var body: some View {
        NavigationStack {
            Form {
                TextField("Vad köpte du?", text: $title)
                TextField("Belopp", text: $amount).keyboardType(.decimalPad)
                Picker("Kategori", selection: $category) { ForEach(categories, id: \.self) { Text($0) } }
            }
            .navigationTitle("Nytt köp")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Avbryt") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Spara") {
                        let normalized = amount.replacingOccurrences(of: ",", with: ".")
                        if let value = Double(normalized), !title.isEmpty {
                            store.addPurchase(title: title, amount: value, category: category)
                            dismiss()
                        }
                    }
                }
            }
        }
    }
}
