import SwiftUI

struct RootView: View {
    var body: some View {
        TabView {
            TodayView()
                .tabItem { Label("Idag", systemImage: "house.fill") }
            CalendarView()
                .tabItem { Label("Kalender", systemImage: "calendar") }
            RoutinesView()
                .tabItem { Label("Rutiner", systemImage: "checklist") }
            MoneyView()
                .tabItem { Label("Pengar", systemImage: "wallet.pass.fill") }
            MoreView()
                .tabItem { Label("Mer", systemImage: "ellipsis.circle.fill") }
        }
        .tint(.indigo)
    }
}
