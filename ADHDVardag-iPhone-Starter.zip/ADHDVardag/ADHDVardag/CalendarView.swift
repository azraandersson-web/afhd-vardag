import SwiftUI

struct CalendarView: View {
    var body: some View {
        NavigationStack {
            VStack(spacing: 18) {
                DatePicker("Kalender", selection: .constant(.now), displayedComponents: .date)
                    .datePickerStyle(.graphical)
                    .padding()
                ContentUnavailableView("Inga händelser ännu", systemImage: "calendar", description: Text("Vi kopplar på riktiga kalenderhändelser i nästa steg."))
                Spacer()
            }
            .navigationTitle("Kalender")
        }
    }
}
