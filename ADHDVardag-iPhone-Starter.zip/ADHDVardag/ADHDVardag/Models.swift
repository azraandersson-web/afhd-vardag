import Foundation

struct DailyTask: Identifiable, Codable {
    let id: UUID
    var title: String
    var subtitle: String
    var icon: String
    var isDone: Bool

    init(id: UUID = UUID(), title: String, subtitle: String = "", icon: String, isDone: Bool = false) {
        self.id = id
        self.title = title
        self.subtitle = subtitle
        self.icon = icon
        self.isDone = isDone
    }
}

struct Purchase: Identifiable, Codable {
    let id: UUID
    var title: String
    var amount: Double
    var category: String
    var date: Date

    init(id: UUID = UUID(), title: String, amount: Double, category: String, date: Date = .now) {
        self.id = id
        self.title = title
        self.amount = amount
        self.category = category
        self.date = date
    }
}

struct BrainDumpItem: Identifiable, Codable {
    let id: UUID
    var text: String
    var date: Date

    init(id: UUID = UUID(), text: String, date: Date = .now) {
        self.id = id
        self.text = text
        self.date = date
    }
}
