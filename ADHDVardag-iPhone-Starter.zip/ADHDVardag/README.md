# ADHD Vardag – iPhone-app

Det här är en första SwiftUI-version av appen från layouten.

## Ingår nu
- Idag-vy med dagliga uppgifter
- Rutiner
- Enkel kalender-vy
- Dagens köp och köphistorik
- Sparmål
- Rökfri-mål med stoppdatum 10 september 2026 som standard
- Automatisk uppskattning av cigaretter inte rökta och pengar sparade
- Brain dump
- Städschema
- Räkningskoll
- "Jag har fastnat"-vy
- Lokal lagring via UserDefaults

## Så öppnar du i Xcode
1. Skapa ett nytt iOS-projekt i Xcode: App, Interface = SwiftUI, Language = Swift.
2. Döp projektet till `ADHDVardag`.
3. Ta bort de genererade Swift-filerna och dra in alla `.swift`-filer från mappen `ADHDVardag/ADHDVardag`.
4. Kör i iPhone Simulator eller på din iPhone.

## Nästa steg
- Riktiga lokala notiser för medicin, tandborstning och räkningar
- EventKit-integration för iPhone-kalender
- Widget för hemskärmen
- Bättre statistik för köp och sparande
- Rökfri "jag är röksugen"-flöde med timer och pepp
- Anpassningsbara rutiner och städschema
